#global constants
MAP_SIZE = 17
